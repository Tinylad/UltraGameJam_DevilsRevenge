using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static Challenge;

public class ChallengeBtnAttachment : MonoBehaviour
{
    public WaveStructure[] waves;
    public GameObject[] weapons;
    public Challenge ChallengePreviewer;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void DisplayChallenge()
    {
        ChallengePreviewer.waves = waves;
        ChallengePreviewer.weapons = weapons;
        ChallengePreviewer.VisualiseWaves();
    }
}
