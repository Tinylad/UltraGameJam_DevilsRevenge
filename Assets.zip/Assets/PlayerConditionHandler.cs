using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerConditionHandler : MonoBehaviour
{

    public int Health;
    public float Invincibleframes;
    public float Invincibletimeremaining;

    public GameObject WeaponHolster;
    public ChallengeManager challengeManager;

    public SpriteRenderer wingsRenderer;
    public SpriteRenderer playerRenderer;

    public int FacingDir;
    public Sprite[] playersprite;

    public AudioSource audiosource;
    public AudioClip hitsound;

    //0 is right, 1 is down, 2 is left, 3 is up



    // Start is called before the first frame update
    void Start()
    {
        
    }

    private void Update()
    {
        if(Invincibletimeremaining>= 0)
        {
            Invincibletimeremaining -= Time.deltaTime;
            playerRenderer.color = new Color(1.0f, Mathf.Pow(1f - Invincibletimeremaining, 3), Mathf.Pow(1f - Invincibletimeremaining, 2), Mathf.Pow(1f - Invincibletimeremaining, 3));
        }

        CheckDeath();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Vector3 mousePosition;
        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePosition.z = 0f;
        Vector3 aimDirection = (mousePosition - transform.position).normalized;
        float angle = Mathf.Atan2(aimDirection.y, aimDirection.x) * Mathf.Rad2Deg;


        if (angle >-45 && angle <= 45)
        {
            //Facing right
            FacingDir = 0;

        }
        if (angle > -135 && angle <= -45)
        {
            //Facing downwards
            FacingDir = 1;
            wingsRenderer.sortingLayerName = "Low";
            
        }
        if ((angle <= -135 || angle > 135))
        {
            //Facing left
            FacingDir = 2;

        }
        if (angle > 45 && angle <= 135)
        {
            //Facing upwards
            FacingDir = 3;
            wingsRenderer.sortingLayerName = "High";


        }
        playerRenderer.sprite = playersprite[FacingDir];
        wingsRenderer.gameObject.GetComponent<Animator>().SetInteger("FacingDir", FacingDir);

    }

    public void Hit(int damage)
    {
        if(Invincibletimeremaining >= 0)
        {
            
        }
        else
        {
            audiosource.PlayOneShot(hitsound);
            Health -= damage;
            Invincibletimeremaining = Invincibleframes;
            playerRenderer.color = new Color(1.0f, .6f, .6f, 1 - Invincibleframes);
        }


    }

    public void CheckDeath()
    {
        if (Health <= 0)
        {
            GetComponent<ParticleSystem>().Emit(50);
            challengeManager.GameFinish(false);
        }
    }
}
