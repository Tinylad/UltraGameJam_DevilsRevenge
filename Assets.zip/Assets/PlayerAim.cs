using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAim : MonoBehaviour
{


    public Transform aimTransform;
    public bool flipped;
    public GameObject player;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 mousePosition;
        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePosition.z = 0f;


        Vector3 aimDirection = (mousePosition - transform.position).normalized;
        float angle = Mathf.Atan2(aimDirection.y, aimDirection.x) * Mathf.Rad2Deg;
        aimTransform.eulerAngles = new Vector3(0, 0, angle);

        if(angle > 90|| angle < -90 && !flipped)
        {
            foreach (Transform child in aimTransform)
            {
                SpriteRenderer rend = child.GetChild(0).GetComponent("SpriteRenderer") as SpriteRenderer;
                rend.flipY = true;
                
            }
            flipped = true;
        }
        else if ( -90<= angle && angle <= 90 && flipped)
        {
            foreach (Transform child in aimTransform)
            {

                SpriteRenderer rend = child.GetChild(0).GetComponent("SpriteRenderer") as SpriteRenderer;
                rend.flipY = false;

            }
            flipped = false;
        }

        if (angle > 0)
        {
            foreach (Transform child in aimTransform)
            { 
            SpriteRenderer rend = child.GetChild(0).GetComponent("SpriteRenderer") as SpriteRenderer;
            rend.sortingLayerName = "Low";
            }
        } else
        {
            foreach (Transform child in aimTransform)
            {
                SpriteRenderer rend = child.GetChild(0).GetComponent("SpriteRenderer") as SpriteRenderer;
                rend.sortingLayerName = "High";

            }
        }

        if (Input.GetButtonDown("Fire1"))
        {
            //Get active weapon

            GameObject activeWeapon = GetActiveWeapon();
            if (activeWeapon != null)
            {
                Weapon weaponScr = activeWeapon.GetComponent("Weapon") as Weapon;
                weaponScr.TryFire();
            }


        }

    }


    GameObject GetActiveWeapon()
    {
        int i = 0;
        GameObject active = null;
        while (i < aimTransform.childCount)
        {
            if (aimTransform.GetChild(i).gameObject.activeSelf)
            {
                active = aimTransform.GetChild(i).gameObject;
            }
            i++;
        }
         if(active == null)
        {
            return null;
        } else
        {
            return active;
        }
    }

    private void FixedUpdate()
    {
        
        
    }

}
