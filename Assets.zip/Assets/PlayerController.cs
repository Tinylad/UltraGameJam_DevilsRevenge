
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    public float movementSpeed;

    private void Start()
    {
        
    }

    private void FixedUpdate()
    {
        Vector2 movement = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));
        transform.position += new Vector3(movement.x,movement.y,0) * Time.deltaTime * movementSpeed;
    }



}
