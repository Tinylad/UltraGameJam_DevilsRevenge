using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class WaveInfo : MonoBehaviour
{
    public GameObject EnemyInfoPrefab;
    public Transform scrollContent;
    public TMP_Text wavetext;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void AddEnemy(GameObject enemy, int enemycount, int yoffset)
    {

        Debug.Log("adding enemy");
        GameObject Info = Instantiate(EnemyInfoPrefab, scrollContent);

        RectTransform rt = Info.GetComponent<RectTransform>();
        rt.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Top, yoffset + 0.5f * rt.rect.height, rt.rect.height);

        Debug.Log(enemy.name);

        EnemyInfo infoScr = Info.GetComponent<EnemyInfo>();
        infoScr.EnemyImage.sprite = enemy.GetComponent<Angel>().previewsprite;
        infoScr.enemyname.text = enemy.name;
        int enemyhealth = enemy.GetComponent<Angel>().health;
        if (enemyhealth < 300)
        {
            infoScr.enemyhealth.maxValue = 300;

        } else if (enemyhealth < 1000)
        {
            infoScr.enemyhealth.maxValue = 1000;

        }
        else
        {
            infoScr.enemyhealth.maxValue = 3000;

        }

        infoScr.enemyhealth.value = enemyhealth;
        infoScr.enemyhealthdigital.text = "Health: " + enemyhealth.ToString();

        infoScr.enemynumber.text = "x" + enemycount;

    }

}
