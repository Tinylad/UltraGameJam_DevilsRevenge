using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public class EnemyRendering : MonoBehaviour
{
    public AstarPath astarPath;
    public float renderRange;
    public Transform player;


    // Start is called before the first frame update
   

    // Update is called once per frame
    void Update()
    {
        
    }

    
}
