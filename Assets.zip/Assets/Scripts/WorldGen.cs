using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using UnityEditor;

public class WorldGen : MonoBehaviour
{
    [Range(0,100)]
    public int iniChance;

    [Range(1,8)]
    public int birthLimit;

    [Range(1,8)]
    public int deathLimit;

    [Range(1,15)]
    public int numRep;
    public int count = 0;

    private int[,] terrainMap;
    public Vector3Int tmapSize;

    public Tilemap topMap;
    public Tilemap botMap;
    public RuleTile topTile;
    public Tile[] botTiles;

    int width;
    int height;

    public GameObject pathfinder;


    void DoSim(int numR)
    {
        clearMap(false);

        width = tmapSize.x;
        height = tmapSize.y;

        if (terrainMap == null)
        {
            terrainMap = new int[width, height];
            initPos();

            
        }


        for (int i = 0; i < numR; i++)
        {
            terrainMap = genTilePos(terrainMap);
        }

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                if (terrainMap[x,y] == 1)
                {
                    topMap.SetTile(new Vector3Int(-x + width / 2, -y + height / 2,0), topTile);

                }
                botMap.SetTile(new Vector3Int(-x + width / 2, -y + height / 2, 0), botTiles[Random.Range(0, botTiles.Length)]);


            }
        }

        

    }

    public void initPos()
    {
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                terrainMap[x, y] = Random.Range(1, 101) < iniChance ? 1 : 0;
            }
        }
        
    }


    

    public int [,] genTilePos(int[,] oldMap)
    {
        int[,] newMap = new int[width, height];
        int neighbours;
        BoundsInt myB = new BoundsInt(-1, -1, 0, 3, 3, 3);

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                neighbours = 0;



                if (x == (int) width / 2 && y == (int)height / 2)
                {
                    foreach (var b in myB.allPositionsWithin)
                    {
                        newMap[x +b.x, y + b.y] = 0;
                    }
                }
                else
                {
                    foreach (var b in myB.allPositionsWithin)
                    {
                        if (b.x == 0 && b.y == 0) continue;

                        if (x + b.x >= 0 && x + b.x < width && y + b.y > 0 && y + b.y < height)
                        {
                            neighbours += oldMap[x + b.x, y + b.y];
                        }
                        else
                        {
                            neighbours++;
                        }
                    }


                    if (oldMap[x, y] == 1)
                    {
                        if (neighbours < deathLimit) newMap[x, y] = 0;
                        else
                        {
                            newMap[x, y] = 1;
                        }
                    }

                    if (oldMap[x, y] == 0)
                    {
                        if (neighbours > birthLimit) newMap[x, y] = 1;
                        else
                        {
                            newMap[x, y] = 0;
                        }
                    }
                }
                

                
            }
        }

        return newMap;
    }

    void clearMap(bool complete)
    {
        topMap.ClearAllTiles();
        botMap.ClearAllTiles();

        if (complete)
        {
            terrainMap = null;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
        if (Input.GetMouseButtonDown(1))
        {
            clearMap(true);
            DoSim(numRep);

        }
    }

    public void ResimPath()
    {
        AstarPath astarPath = pathfinder.GetComponent("AstarPath") as AstarPath;
        astarPath.Scan();
    }

    void Start()
    {
        DoSim(numRep);
        Invoke("ResimPath",2f);
    }
}
