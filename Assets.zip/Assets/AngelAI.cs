using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public class AngelAI : MonoBehaviour
{
    public Vector3 target;
    public Transform player;
    public float moveSpeed = 200f;
    public float nextWaypointDistance = 3f;
    private Vector3 startingPosition;
    private Vector3 roamPosition;

    public float distanceToAttack;
    public bool targetingPlayer = false;

    Path path;
    int currentWaypoint = 0;
    bool reachedEndOfPath = false;

    Seeker seeker;
    Rigidbody2D rb;

    public Transform graphics;


    // Start is called before the first frame update
    void Start()
    {
        seeker = GetComponent<Seeker>();
        rb = GetComponent<Rigidbody2D>();
        InvokeRepeating("UpdateState", 0f, 2f);
        InvokeRepeating("UpdatePath", 0f, 0.2f);

        startingPosition = transform.position;
        roamPosition = GetRoamingPosition();


    }

    private void OnDrawGizmos()
    {
        if (targetingPlayer)
        {
            Gizmos.color = Color.red;
        }
        else
        {
            Gizmos.color = Color.blue;
        }
        Gizmos.DrawWireSphere(transform.position, distanceToAttack);


        if (path != null)
        {
            if (currentWaypoint < path.vectorPath.Count)
            {
                Vector2 direction = ((Vector2)path.vectorPath[currentWaypoint] - rb.position).normalized;
                Vector2 force = direction * moveSpeed * Time.deltaTime;

                Gizmos.DrawLine(transform.position, transform.position + new Vector3(direction.x, direction.y, 0f) * moveSpeed * Time.deltaTime);
            }
        }
        
    }
    public void UpdatePath()
    {
        if (seeker.IsDone())
        {
            if (targetingPlayer)
            {
                seeker.StartPath(rb.position, player.position, OnPathComplete);

            }
            else
            {
                if (reachedEndOfPath)
                {
                    //Find new random position
                    seeker.StartPath(rb.position, GetRoamingPosition(), OnPathComplete);

                }
                else
                {
                    seeker.StartPath(rb.position, roamPosition, OnPathComplete);
                }
            }
        }
            
    }

    public void UpdateState()
    {
        if (Vector2.Distance((Vector2)player.position, rb.position) > distanceToAttack)
        {
            targetingPlayer = false;

        }
        else
        {
            targetingPlayer = true;
        }
    }

    void OnPathComplete(Path p)
    {
        if (!p.error)
        {
            path = p;
            currentWaypoint = 0;
        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (path == null)
            return;

        if (currentWaypoint >= path.vectorPath.Count)
        {
            reachedEndOfPath = true;
        }
        else
        {
            reachedEndOfPath = false;

            Vector2 direction = ((Vector2)path.vectorPath[currentWaypoint] - rb.position).normalized;
            Vector2 force = direction * moveSpeed * Time.deltaTime;



            rb.AddForce(force);

            float distance = Vector2.Distance(rb.position, path.vectorPath[currentWaypoint]);

            if (distance < nextWaypointDistance)
            {
                currentWaypoint++;
            }

            if (currentWaypoint < path.vectorPath.Count - 1)
            {
                Vector2 dir = ((Vector2)path.vectorPath[currentWaypoint] - rb.position).normalized;
                SpriteRenderer rend = GetComponentInChildren<SpriteRenderer>();

                if (dir.x > 0.1f)
                {

                    rend.flipX = true;

                }
                else if (dir.x < 0.1f)
                {
                    rend.flipX = false;

                }
            }

            
        }

        
    }



    private void Update()
    {
        UpdateState();
        
    }
    private Vector3 GetRoamingPosition()
    {
        roamPosition = startingPosition + new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), Random.Range(-1f, 1f)) * Random.Range(10f, 7f);
        return roamPosition;


    }
}
