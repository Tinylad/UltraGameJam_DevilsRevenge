using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using static Challenge;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ChallengeManager : MonoBehaviour
{

    public ChallengeInfo infocontainer;
    public WaveStructure[] waves;
    public GameObject[] startweapons;
    public int enemieskilled;
    public int currentwave = 0;
    public int enemieskilledinwave;
    public int enemiesalive;
    public EnemyManager enemyManager;
    public GameObject Player;
    public BulletPool bulletpool;

    public List<Rect> successfulrects;
    public List<Rect> failedrects;

    public GameObject transition;
    public GameObject enemycontainer;

    // Start is called before the first frame update
    void Start()
    {
    }

    

    // Update is called once per frame
    void Update()
    {
        if (currentwave == waves.Length - 1)
        {
            //Final wave
            if (enemiesalive <= 0 && waves.Length > 0)
            {
                GameFinish(true);
            }
        }
        else if (waves.Length > 1)
        {
            if (enemieskilledinwave >= waves[currentwave + 1].EnemyKillsToLevel)
            {
                //Start the next wave
                StartWave(currentwave + 1);
                currentwave += 1;
                enemieskilledinwave = 0;
            }
        }
        
    }

    public void StartGame()
    {
        Invoke("StartWave", 1f);
    }


    public void StartWave(int wavetostart = 0)
    {
        Debug.Log("Starting wave " + wavetostart);
        int i = 0;
        foreach (GameObject enemy in waves[wavetostart].Enemies)
        {
            SpawnEnemy(enemy, (int)waves[wavetostart].EnemyCount[i]);
            i++;
        }


    }

    void VisualiseTestAreas()
    {
        for (int i = -100; i < 100; i++)
        {
            for (int j = -100; j < 100; j++)
            {
                Vector2 testpos = new Vector2(i, j);
                Vector2 testarea = new Vector2(10f, 10f);


                if (Physics2D.OverlapArea(testpos - testarea * 0.5f, testpos + testarea * 0.5f) != null)
                {

                    //Spawn enemy
                    successfulrects.Add(new Rect(testpos.x, testpos.y, testarea.x, testarea.y));
                }
                else
                {
                    failedrects.Add(new Rect(testpos.x, testpos.y, testarea.x, testarea.y));

                }
            }
        }
    }


    public void SpawnEnemy(GameObject enemy, int enemycount)
    {
        Debug.Log("Spawning enemy group");
        for (int i = 0; i < enemycount + 1; i++)
        {
            bool validspawn = false;
            Vector2 testpos = new Vector2(0, 0);
            while (!validspawn)
            {
                //Try a random location within 75 tiles of the player
                testpos = new Vector2(UnityEngine.Random.Range(-80f, 80f), UnityEngine.Random.Range(-80f, 80f));
                Vector2 testarea = new Vector2(6f, 6f);
                

                if (Physics2D.OverlapArea(testpos - testarea * 0.5f, testpos + testarea * 0.5f) == null)
                {

                    //Spawn enemy
                    validspawn = true;
                    Debug.Log("Spawning enemy");
                    successfulrects.Add(new Rect(testpos.x, testpos.y, testarea.x, testarea.y));
                }
                else
                {
                    Debug.Log("Failed test spot for enemy");
                    failedrects.Add(new Rect(testpos.x, testpos.y, testarea.x, testarea.y));

                }


            }
            GameObject enemyToSpawn = Instantiate(enemy, enemycontainer.transform);
            Angel angel = enemyToSpawn.GetComponent<Angel>();
            angel.attack.pooltofirefrom = bulletpool;
            angel.player = Player.transform;
            angel.manager = this;
            angel.slider.maxValue = angel.health;
            enemyToSpawn.GetComponent<AngelAI>().player = Player.transform;
            enemyToSpawn.transform.position = new Vector3(testpos.x, testpos.y, 0);
            Debug.Log("spawning");
        }
    }


    public void SetWeapons(GameObject[] weapons)
    {
        WeaponManager weaponManager = Player.GetComponentInChildren<WeaponManager>();
        weaponManager.weapons = weapons;
        
        foreach (Transform child in weaponManager.transform)
        {
            Destroy(child.gameObject);
        }
        foreach(GameObject weapon in weapons)
        {
            weapon.transform.SetParent(weaponManager.transform);
            weapon.transform.position = new Vector3(0f, 0f, 0f);
            weapon.SetActive(false);
        }
        weapons[0].SetActive(true);

    }

    public void GameFinish(bool win)
    {
        if (win)
        {
            infocontainer.winpanel.SetActive(true);
        }
        else
        {
            infocontainer.deathpanel.SetActive(true);

        }
    }

    public void ReturnToChallenges(bool success)
    {

        Debug.Log("Returning to challenge select");
        foreach (Transform child in enemycontainer.transform)
        {
            GameObject.Destroy(child.gameObject);
        }
        StartCoroutine(LoadLevel(0));
    }

    IEnumerator LoadLevel(int buildindex)
    {
        transition.GetComponent<Animator>().SetTrigger("Transition");

        yield return new WaitForSeconds(0.3f);

        SceneManager.LoadScene(buildindex);
    }
}