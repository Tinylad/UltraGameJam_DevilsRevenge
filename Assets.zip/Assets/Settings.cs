using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Settings : MonoBehaviour
{

    public Texture2D devilTexture;
    public Texture2D angelTexture;

    // Start is called before the first frame update
    void Start()
    {
        Cursor.SetCursor(devilTexture, new Vector2(0.5f, 0.5f) * devilTexture.width, CursorMode.ForceSoftware);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
