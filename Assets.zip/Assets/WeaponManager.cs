using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class WeaponManager : MonoBehaviour
{

    public GameObject[] weapons;
    public GameObject Pickuptarget;

    public GameObject[] frames;
    public GameObject[] weaponItems;
    public WeaponUI[] UIWeapons;

    public ParticleSystem weaponFX;

    [Serializable]
    public class WeaponUI
    {
        public GameObject frame;
        public Image item;
        public Slider levelslider;
        public TMP_Text text;
    }

    // Start is called before the first frame update
    void Start()
    {
        

    }

    public void GetWeapons()
    {
        weapons = new GameObject[transform.childCount];
        int i = 0;
        foreach (Transform child in transform)
        {
            weapons[i] = child.gameObject;
            i++;
        }
        UpdateItems();
        UpdateItemFrames();
    }

    // Update is called once per frame
    void Update()
    {
        TestSwapWeapons();
        
        TestPickupWeapon();
        

        for (int i = 0; i < weapons.Length; i++)
        {
            Weapon weaponScr = weapons[i].GetComponent<Weapon>();
            float percentlefttocool = 1 - weaponScr.timeToCool / weaponScr.levels[weaponScr.weaponlevel].cooldown;


            UIWeapons[i].item.color = new Color(percentlefttocool, 1f, 1f, percentlefttocool * 2f);
            
        }

    }

    void TestPickupWeapon()
    {
        if (Input.GetButtonDown("Interact"))
        {
            if(weapons.Length < 6 && Pickuptarget != null)
            {
                Pickuptarget.transform.SetAsFirstSibling();
                Pickuptarget.transform.position = new Vector3(0f, 0f, 0f);

                weapons = new GameObject[transform.childCount];
                int i = 0;
                foreach (Transform child in transform)
                {
                    weapons[i] = child.gameObject;
                    i++;
                }
                UpdateItems();

                UpdateItemFrames();
            }
        }
    }

    void TestSwapWeapons() {
        if (Input.GetButtonDown("NextWeapon"))
        {
            //Switch selected guns (downwards)

            for (int i = 0; i < weapons.Length - 1; i++)
            {

                GameObject temp = weapons[i + 1];
                weapons[i + 1] = weapons[i];
                weapons[i] = temp;
            }

        }
        else if (Input.GetButtonDown("PrevWeapon"))
        {
            //Switch selected guns (upwards)
            GameObject temp = weapons[weapons.Length - 1];

            for (int i = weapons.Length - 1; i > 0; i--)
            {
                weapons[i] = weapons[i-1];

            }
            weapons[0] = temp;
        }

        for (int i = 0; i < weapons.Length; i++)
        {
            if (weapons[i] != null)
            {
                if (i == 0)
                {
                    weapons[i].SetActive(true);

                }
                else
                {
                    weapons[i].SetActive(false);

                }
            }
            
        }

        UpdateItems();
        UpdateItemFrames();
    }


    public void UpdateItemFrames()
    {

        

        for (int i = 0; i < weapons.Length; i++)
        {
            UIWeapons[i].frame.SetActive(true);

            int weaponLevel = weapons[i].GetComponent<Weapon>().weaponlevel;
            if (weaponLevel < weapons[i].GetComponent<Weapon>().levels.Length - 1)
            {
                UIWeapons[i].levelslider.maxValue = weapons[i].GetComponent<Weapon>().levels[weaponLevel + 1].damagetolevel;
                UIWeapons[i].levelslider.value = UIWeapons[i].levelslider.maxValue - weapons[i].GetComponent<Weapon>().damagedealt;
            }
            else
            {
                UIWeapons[i].levelslider.maxValue = 1;
                UIWeapons[i].levelslider.value = 1;
            }

            UIWeapons[i].text.text = UIWeapons[i].item.sprite.name;
            
        }
    }

    public void UpdateItems()
    {

        for (int i = 0; i < weapons.Length; i++)
        {
           UIWeapons[i].item.sprite = weapons[i].GetComponentInChildren<SpriteRenderer>().sprite;
            UIWeapons[i].item.SetNativeSize();
        }
    }

    public void UpdateWeaponLevel(int damagedealt)
    {
        weapons[0].GetComponent<Weapon>().UpdateWeaponDmg(damagedealt);

        int weaponLevel = weapons[0].GetComponent<Weapon>().weaponlevel;
        if (weaponLevel < weapons[0].GetComponent<Weapon>().levels.Length - 1)
        {
            UIWeapons[0].levelslider.maxValue = weapons[0].GetComponent<Weapon>().levels[weaponLevel + 1].damagetolevel;
            UIWeapons[0].levelslider.value = weapons[0].GetComponent<Weapon>().damagedealt;

        }
        else
        {
            UIWeapons[0].levelslider.maxValue = 1;
            UIWeapons[0].levelslider.value = 1;
        }

        

    }

    public void LevelChange(bool MaxedOut)
    {
        if (MaxedOut)
        {
            weaponFX.Emit(50);
            weaponFX.Emit(30);
        }
        else
        {
            weaponFX.Emit(40);
        }
    }
    
}
