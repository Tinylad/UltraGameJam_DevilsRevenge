using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class FireArc : MonoBehaviour
{


    public int bulletsAmount = 10;
    public int damage;
    public float coolDownTime;
    public float timeToReady = 0;

    [SerializeField]
    private float spread = 360f;

    private Vector2 bulletMoveDirection;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        
        {
            if (timeToReady > 0)
            {
                timeToReady -= Time.deltaTime;
            }
        }
    }

    public void Fire()
    {
        float startAngle = 90f - spread / 2;
        float endAngle = 90f + spread / 2;



        float angleStep = (endAngle - startAngle) / bulletsAmount;
        float angle = startAngle - transform.eulerAngles.z;

        for (int i = 0; i < bulletsAmount; i++)
        {
            float bulDirX = transform.position.x + Mathf.Sin((angle * Mathf.PI) / 180f);
            float bulDirY = transform.position.y + Mathf.Cos((angle * Mathf.PI) / 180f);

            Vector3 bulMoveVector = new Vector3(bulDirX, bulDirY, 0f);
            Vector2 bulDir = (bulMoveVector - transform.position).normalized;

            GameObject bul = BulletPool.bulletPoolInstance.GetBullet();

            bul.transform.position = transform.position;
            bul.SetActive(true);
            bul.GetComponent<Bullet>().SetMoveDirection(bulDir, 25f);
            bul.GetComponent<Bullet>().SetDamage(damage, false);


            angle += angleStep;

        }

        timeToReady = coolDownTime;
    }
}
