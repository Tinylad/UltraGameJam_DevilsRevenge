using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;
using Pathfinding;
using UnityEditor;

public class Angel : MonoBehaviour
{
    public ChallengeManager manager;

    public Sprite previewsprite;
    public float numberval;
    public float difficultval;

    public Transform player;

    public int health;
    public Rigidbody2D rb;
    public SpriteRenderer rend;
    private AngelAI AI;

    public EnemyPool pool;
    public Slider slider;
    public GameObject indicator;
    Renderer rd;

    public Attack attack;

    public bool destroyed = false;
    public AudioClip hitsound;
    public AudioClip deathsound;

    [Serializable]

    public class Attack {

        public Transform target;
        public BulletPool pooltofirefrom;

        public float cooldown;
        public float coolingTime;

        public float attackRange;
        public bool attackReady;

        public float spread;
        public float angleStep;
        public float randomSpread;

        public int damage;
        public int numBullets;
        public int penetration;

        public Transform emitter;
        public AudioClip shootclip;
        public AudioSource soundsource;


        public void Fire(float offset)
        {
            

            float angle, angleStep;
            if (offset < 0) //-1 means fire towards player
            {
                float startAngle = 90f - spread / 2;
                float endAngle = 90f + spread / 2;



                angleStep = (endAngle - startAngle) / numBullets;
                Vector3 dir = target.position - emitter.transform.position;
                angle = startAngle - Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg + offset;
            }
            else
            {
                float startAngle = 90f - spread / 2;
                float endAngle = 90f + spread / 2;



                angleStep = (endAngle - startAngle) / numBullets;
                angle = startAngle + offset;
            }
            Debug.Log("FIRING");
            

            for (int i = 0; i < numBullets; i++)
            {
                float bulDirX = emitter.position.x + Mathf.Sin((angle * Mathf.PI) / 180f);
                float bulDirY = emitter.position.y + Mathf.Cos((angle * Mathf.PI) / 180f);
                Vector2 bulDir;
                if (bulDirX > 0)
                {
                    Vector3 bulMoveVector = new Vector3(bulDirX, bulDirY, 0f) + new Vector3(UnityEngine.Random.Range(-0.1f, 0.1f), UnityEngine.Random.Range(-0.1f, 0.1f), 0) * randomSpread;
                    bulDir = (bulMoveVector - emitter.position).normalized + new Vector3(UnityEngine.Random.Range(-0.1f, 0.1f), UnityEngine.Random.Range(-0.1f, 0.1f), 0) * randomSpread;
                }
                else
                {
                    Vector3 bulMoveVector = new Vector3(bulDirX, bulDirY, 0f);
                    bulDir = (bulMoveVector - emitter.position).normalized;
                }



                GameObject bul = pooltofirefrom.GetBullet();

                bul.transform.position = emitter.position;
                bul.SetActive(true);
                bul.GetComponent<Bullet>().SetMoveDirection(bulDir, 25f);
                bul.GetComponent<Bullet>().SetDamage(damage, true);


                angle += angleStep;
                soundsource.PlayOneShot(shootclip);
            }

            coolingTime = 0 + UnityEngine.Random.Range(-0.2f,0.1f);
            
        }

       

    }

    

    // Start is called before the first frame update
    void Start()
    {
        AI = GetComponent<AngelAI>();

        InvokeRepeating("TestAttackReady", 3f, 0.5f);
        attack.target = player;
        manager.enemiesalive += 1;

    }

    private void OnEnable()
    {
        if (pool != null)
        {
        }
        slider.value = 0;

    }


    public void Reset(int healthtoset)
    {
        slider.maxValue = healthtoset;
        pool = GetComponentInParent<EnemyPool>();
        pool.EnemiesAlive = pool.EnemiesAlive + 1;
        health = healthtoset;
        InvokeRepeating("TestAttackReady", 0f, 3f);
    }

    private void OnDisable()
    {
        CancelInvoke();

    }

    private void Destroy()
    {
        CancelInvoke();
        Destroy(indicator);
        Destroy(this.gameObject);
        manager.enemieskilled += 1;
        manager.enemieskilledinwave += 1;
        manager.enemiesalive -= 1;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        

        attack.coolingTime += Time.fixedDeltaTime;
    }

    public void Hit(int damage = 0)
    {
        rend.color = new Color(.7f, .1f, .1f, .7f);
        health -= damage;
        slider.value = slider.maxValue - health;
        attack.soundsource.PlayOneShot(hitsound);
        CheckDeath();
        AI.UpdatePath();


    }

    void CheckDeath()
    {
        if (health <= 0 && !destroyed)
        {
            attack.soundsource.PlayOneShot(deathsound);

            destroyed = true; Destroy(indicator);
            Invoke("Destroy", 0.5f);
        }
    }


    void TestAttackReady()
    {
        Debug.Log("testing");
        if(Vector2.Distance((Vector2)player.position, rb.position) < attack.attackRange)
        {
            Debug.Log("Player within range");
            if (attack.coolingTime >= attack.cooldown && !destroyed)
            {
                Debug.Log("Attacking");
                GetComponent<Animator>().SetTrigger("Attack");
            }
        }
    }


    public void Fire(float offset)
    {
        if (!destroyed)
        {
            Debug.Log("Firing");
            attack.Fire(offset);
            GetComponent<Animator>().ResetTrigger("Attack");
        }
        
    }



    private void Update()
    {
        //Place indicator for the current enemy if offscreen
        if (!destroyed)
        {
            if (Vector3.Distance(transform.position, player.position) > 30)
            {
                Vector2 screenPos = Camera.main.WorldToViewportPoint(transform.position); //get viewport positions

                if (screenPos.x >= 0 && screenPos.x <= 1 && screenPos.y >= 0 && screenPos.y <= 1)
                {
                    Debug.Log("already on screen, don't bother with the rest!");
                    return;
                }

                Vector2 onScreenPos = new Vector2(screenPos.x - 0.5f, screenPos.y - 0.5f) * 2; //2D version, new mapping
                float max = Mathf.Max(Mathf.Abs(onScreenPos.x), Mathf.Abs(onScreenPos.y)); //get largest offset
                onScreenPos = (onScreenPos / (max * 2)) + new Vector2(0.5f, 0.5f); //undo mapping
                Debug.Log(onScreenPos);

                indicator.transform.position = Camera.main.transform.position + new Vector3((onScreenPos.x - 0.5f) * 45f, (onScreenPos.y - 0.5f) * 23f,3f);
                indicator.transform.parent = Camera.main.transform;
                indicator.SetActive(true);
            }
            else
            {
                if (indicator.activeSelf == true)
                {
                    indicator.SetActive(false);
                }
            }


            //Change colour to normal
            
        }
        
            rend.color = rend.color + new Color(.1f, .1f, .1f, .1f);
        Invoke("ResetColor", 1f);
        
    }

    public void ResetColor()
    {
        rend.color = new Color(1f, 1f, 1f, 1f);
    }
}
