using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class Challenge : MonoBehaviour
{

    public WaveStructure[] waves;

    public GameObject[] weapons;
    public Transform weaponcontainer;

    public GameObject waveObject;
    public GameObject challengebar;
    public GameObject WaveInfoPrefab;
    public Transform waveContainer;

    public GameObject transitioncover;

    

    [Serializable]
    public class WaveStructure
    {
        public int EnemyKillsToLevel;

        public GameObject[] Enemies;
        public int[] EnemyCount;
    }

    public GameObject transition;

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnEnable()
    {
    }

    public void Function()
    {

    }

    public void VisualiseWaves()

    {
        DisplayWeapons();

        float width = challengebar.GetComponent<RectTransform>().rect.width;

        foreach(Transform child in challengebar.transform)
        {
            GameObject.Destroy(child.gameObject);
        }

        float distancestep = width / (waves.Length + 1);

        Debug.Log("Width is " + width);
        Debug.Log("Distance step is " + distancestep);

        for (int i = 0; i < waves.Length; i++)
        {
            GameObject waveIdentifier = Instantiate(waveObject, challengebar.transform);
            RectTransform rt = waveIdentifier.GetComponent<RectTransform>();
            rt.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Left, distancestep * (i+1) - 0.5f * rt.rect.width, rt.rect.width);

            if (waves.Length > 5)
            {
                waveIdentifier.GetComponentInChildren<Text>().text = (i + 1).ToString();

            }
            else
            {
                waveIdentifier.GetComponentInChildren<Text>().text = "Wave " + (i + 1);

            }
            int id = i;
            waveIdentifier.GetComponent<Button>().onClick.AddListener(delegate () { VisualiseWaveInfo(id); });

        }

        VisualiseWaveInfo(0);

    }
    
    public void VisualiseWaveInfo(int wave)
    {
        Debug.Log("Visualising wave " + wave);
        foreach (Transform child in waveContainer)
        {
            GameObject.Destroy(child.gameObject);
        }

        GameObject wavetovisualise = Instantiate(WaveInfoPrefab, waveContainer);

        RectTransform rt = wavetovisualise.GetComponent<WaveInfo>().scrollContent.GetComponent<RectTransform>();
        rt.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Top, waves[wave].Enemies.Length * 130f / 2f, waves[wave].Enemies.Length * 140f);
        wavetovisualise.GetComponent<WaveInfo>().wavetext.text = "Wave " + (wave+1).ToString();
        int i = 0;
        foreach (GameObject enemy in waves[wave].Enemies)
        {
            wavetovisualise.GetComponent<WaveInfo>().AddEnemy(enemy, waves[wave].EnemyCount[i], i * 130 - 50);

            i++;
        }
    }


    public void DisplayWeapons()
    {

        int weaponCount = 0;
        for (int i = 0; i < weapons.Length; i++)
        {
            if (weapons[i] != null)
            {
                weaponCount++;
            }
        }

        RectTransform rt = weaponcontainer.GetComponent<RectTransform>();
        rt.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Top, weaponCount * 320 * 0.5f, weaponCount * 320 * 0.5f);


        int k = 0;
        foreach (Transform child in weaponcontainer)
        {
            if(k >= weaponCount)
            {
                child.GetChild(0).gameObject.SetActive(false);

                
            }
            else
            {
                child.GetChild(0).gameObject.SetActive(true);
                child.GetChild(0).GetComponent<Image>().sprite = weapons[k].GetComponent<Weapon>().levels[weapons[k].GetComponent<Weapon>().level].sprite;
                k++;
            }

            
        }
    }


    public void StartGame()
    {
        Debug.Log("Starting game");

        
       

        StartCoroutine(LoadChallenge(1));


        
    }

    private void FixedUpdate()
    {
        

        
    }


    IEnumerator LoadChallenge(int buildindex)
    {
        transition.GetComponent<Animator>().SetTrigger("Transition");

        yield return new WaitForSeconds(0.2f);

        SceneManager.LoadScene(buildindex,LoadSceneMode.Additive);

        yield return new WaitForSeconds(0.2f);

        ChallengeManager currentChallenge = GameObject.Find("World").GetComponent<ChallengeManager>();
        currentChallenge.waves = waves;
        currentChallenge.startweapons = weapons;

        GameObject playerInstance = GameObject.Find("Player");
        playerInstance.GetComponent<PlayerConditionHandler>().Health = 600;

        GameObject holster = playerInstance.GetComponent<PlayerConditionHandler>().WeaponHolster;

        foreach (GameObject weapon in weapons)
        {
            Instantiate(weapon, holster.transform);
        }
        holster.GetComponent<WeaponManager>().GetWeapons();

        currentChallenge.StartGame();

        SceneManager.SetActiveScene(SceneManager.GetSceneByBuildIndex(1));
        SceneManager.UnloadSceneAsync(0);
    }
}






