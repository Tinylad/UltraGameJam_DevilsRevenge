using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ChallengeInfo : MonoBehaviour
{

    public ChallengeManager manager;
    public Slider waveSlider;
    public TMP_Text slidertext;
    public TMP_Text waveNum;
    public TMP_Text enemiesAlive;

    public Slider playerhealth;

    public GameObject deathpanel;
    public GameObject winpanel;

    public GameObject transitioncover;

    // Start is called before the first frame update
    void Start()
    {
        playerhealth.maxValue = 600;
    }

    // Update is called once per frame
    void Update()
    {

        if (manager.currentwave == manager.waves.Length - 1)
        {
            //Final wave
            waveNum.text = "Final \n wave";

        }
        else if(manager.waves.Length > 1)
        {
            waveSlider.maxValue = manager.waves[manager.currentwave + 1].EnemyKillsToLevel;
            waveSlider.value = manager.enemieskilledinwave;
            slidertext.text = manager.enemieskilled.ToString() + "\n enemies \n killed";

            waveNum.text = "Wave \n " + (manager.currentwave + 1).ToString();

        }

        playerhealth.value = 600 - manager.Player.GetComponent<PlayerConditionHandler>().Health;
        enemiesAlive.text = manager.enemiesalive + "Enemies alive";
    }
}
