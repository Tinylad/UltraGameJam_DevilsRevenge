using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{

    private Vector2 moveDirection;
    private float moveSpeed = 5f;
    private int bulletdamage;
    public WeaponManager weaponmanager;
    public bool IsAngelic;
    

    // Start is called before the first frame update
    private void OnEnable()
    {
        GetComponent<ParticleSystem>().Emit(20);
        GetComponent<SpriteRenderer>().enabled = true;
        Invoke("Destroy", 3f);
    }

    private void OnDisable()
    {
        CancelInvoke();
    }

    private void Destroy()
    {
        gameObject.SetActive(false);
    }

    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(moveDirection * moveSpeed * Time.deltaTime);
    }

    public void SetMoveDirection(Vector2 dir, float Speed = 5f)
    {
        moveDirection = dir;
        moveSpeed = Speed;
    }

    public void SetDamage(int damage, bool Angelic)
    {
        bulletdamage = damage + (int)Random.Range(-3, 3);
        IsAngelic = Angelic;
    }

    


    void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Hit Enemy");


        if (GetComponent<SpriteRenderer>().enabled == true)
        {
            if (other.gameObject.tag == "Wall")
            {
                Debug.Log("bullet hit a wall");
                GetComponent<ParticleSystem>().Emit(30);
                GetComponent<SpriteRenderer>().enabled = false;
                Invoke("Destroy", 0.5f);
            }
            else if (other.gameObject.tag == "Enemy" && !IsAngelic)
            {
                Debug.Log("Hit Enemy" + moveDirection);
                Angel angel = other.gameObject.GetComponent("Angel") as Angel;
                angel.Hit(bulletdamage);
                angel.rb.AddForce(moveDirection * 10 * bulletdamage);

                weaponmanager.UpdateWeaponLevel(bulletdamage);
                GetComponent<SpriteRenderer>().enabled = false;
                GetComponent<ParticleSystem>().Emit(30);
                Invoke("Destroy", 0.5f);
            } else if (other.gameObject.tag == "Player" && IsAngelic)
            {
                other.GetComponentInParent<PlayerConditionHandler>().Hit(bulletdamage);
                GetComponent<SpriteRenderer>().enabled = false;
                GetComponent<ParticleSystem>().Emit(30);
                Invoke("Destroy", 0.5f);
            }
        }
        


    }


}
