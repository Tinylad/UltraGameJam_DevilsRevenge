using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

public class Weapon : MonoBehaviour
{

    public float timeToCool;

    public float spread;
    public float randomSpread;
    public bool auto;

    public int weaponlevel = 0;
    public int damagedealt;

    [SerializeField] public WeaponInfo[] levels;
    public Transform emitter;

    public int level;

public AudioSource audiosource;

        public AudioClip shootclip;
    public AudioClip levelup;

    // Start is called before the first frame update
    void Start()
    {
        NextLevel(0);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    [Serializable]
    public class WeaponInfo
    {
        public Sprite sprite;
        public int damagetolevel;
        public int damage;
        public int numBullets;
        public int penetration;
        public float cooldown;
        
    }


    private void NextLevel(int level)
    {

        if (level < levels.Length && transform.parent != null)
        {
            transform.GetComponentInChildren<SpriteRenderer>().sprite = levels[weaponlevel].sprite;
            
            weaponlevel = level;

            if (level == levels.Length - 1)
            {
                //Weapon is now maxxed out
                GetComponentInParent<WeaponManager>().LevelChange(true);
            }
            else
            {
                GetComponentInParent<WeaponManager>().LevelChange(false);

            }
        }
        audiosource.PlayOneShot(levelup);

    }

    private void FixedUpdate()
    {
        if (timeToCool > 0)
        {
            timeToCool -= Time.fixedDeltaTime;
        }
    }

    public void Fire()
    {
        float startAngle = 90f - spread / 2;
        float endAngle = 90f + spread / 2;



        float angleStep = (endAngle - startAngle) / levels[weaponlevel].numBullets;
        float angle = startAngle - transform.eulerAngles.z;

        for (int i = 0; i < levels[weaponlevel].numBullets; i++)
        {
            float bulDirX = transform.position.x + Mathf.Sin((angle * Mathf.PI) / 180f);
            float bulDirY = transform.position.y + Mathf.Cos((angle * Mathf.PI) / 180f);
            Vector2 bulDir;
            if (bulDirX > 0)
            {
                Vector3 bulMoveVector = new Vector3(bulDirX, bulDirY, 0f) + new Vector3(UnityEngine.Random.Range(-0.1f,0.1f), UnityEngine.Random.Range(-0.1f, 0.1f),0) * randomSpread;
                bulDir = (bulMoveVector - transform.position).normalized + new Vector3(UnityEngine.Random.Range(-0.1f, 0.1f), UnityEngine.Random.Range(-0.1f, 0.1f), 0) * randomSpread;
            }
            else
            {
                Vector3 bulMoveVector = new Vector3(bulDirX, bulDirY, 0f);
                bulDir = (bulMoveVector - transform.position).normalized;
            }

            

            GameObject bul = BulletPool.bulletPoolInstance.GetBullet();

            bul.transform.position = emitter.position;
            bul.SetActive(true);
            bul.GetComponent<Bullet>().SetMoveDirection(bulDir, 25f);
            bul.GetComponent<Bullet>().SetDamage(levels[weaponlevel].damage, false);


            angle += angleStep;
            audiosource.PlayOneShot(shootclip);

        }

        timeToCool = levels[weaponlevel].cooldown;
    }

    public void TryFire()
    {
        if(timeToCool <= 0)
        {
            if (auto)
            {
                InvokeRepeating("AutoFire", 0f, levels[weaponlevel].cooldown);
            }
            else
            {
                Fire();

            }
        }


    }

    public void UpdateWeaponDmg(int damagedealtparam)
    {
        damagedealt += damagedealtparam;
        if (weaponlevel == levels.Length - 1)
        {

        } else if (damagedealt >= levels[weaponlevel + 1].damagetolevel)
        {
            NextLevel(weaponlevel + 1);
            damagedealt = 0;
        }
        
        
    }


    public void AutoFire()
    {
        if (Input.GetButton("Fire1"))
        {
            Fire();
        }
        else
        {
            CancelInvoke();
        }
    }

}
