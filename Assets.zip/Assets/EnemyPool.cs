using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyPool : MonoBehaviour
{
    public EnemyManager manager;
    public Transform player;

    public float numberval;
    public float difficultval;

    public static EnemyPool poolInstance;

    public GameObject pooledEnemy;
    private bool notEnoughInstances = true;

    private List<GameObject> Enemies;
    public int EnemiesAlive;

    private void Awake()
    {
        poolInstance = this;
        InvokeRepeating("SpawnEnemies", 0f, 3f);
    }


    private void Start()
    {
        Enemies = new List<GameObject>();

        
    }

    public GameObject GetEnemy()
    {
        if (Enemies.Count > 0)
        {
            for (int i = 0; i < Enemies.Count; i++)
            {
                if (!Enemies[i].activeInHierarchy)
                {
                    Angel angelScr = Enemies[i].GetComponent<Angel>();
                    angelScr.Reset(pooledEnemy.GetComponent<Angel>().health + (int)Random.Range(0f, 40f));
                    


                    return Enemies[i];
                }
            }
        }

        if (notEnoughInstances)
        {
            Debug.Log("Instantiating new enemy");
            GameObject enemy = Instantiate(pooledEnemy, poolInstance.transform);
            enemy.GetComponent<Angel>().pool = this;
            enemy.SetActive(false);
            Enemies.Add(enemy);
            enemy.GetComponent<Angel>().Reset(pooledEnemy.GetComponent<Angel>().health + (int)Random.Range(0f, 40f));
            enemy.GetComponent<Angel>().attack.pooltofirefrom = pooledEnemy.GetComponent<Angel>().attack.pooltofirefrom;
            return enemy;
        }

        return null;
    }

    // Update is called once per frame
    void Update()
    {
        


        Debug.Log(Enemies.Count + " Enemies");
        
    }

    public void SpawnEnemies()
    {

        int enemycount = 0;
        foreach (Transform child in poolInstance.transform)
        {
            if (child.gameObject.activeSelf)
            {
                enemycount++;
            }
        }

        Debug.Log(enemycount);
        if (enemycount < 13 && enemycount > 0)
        {
            Debug.Log("Spawning more enemies");
            manager.SpawnEnemy(this, 3);
        }
    }

}
