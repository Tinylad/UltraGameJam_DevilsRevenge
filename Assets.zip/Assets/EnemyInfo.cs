using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class EnemyInfo : MonoBehaviour
{
    public Image EnemyImage;
    public Text enemyname;
    public Slider enemyhealth;
    public Text enemynumber;
    public TMP_Text enemyhealthdigital;

    
}
