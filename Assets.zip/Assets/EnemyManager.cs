using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class EnemyManager : MonoBehaviour
{
    public float gameTime = 0;
    public float difficulty;

    public GameObject Player;

    public GameObject[] BasicAngels;
    public EnemyPool[] EnemyPools;
    public GameObject EnemyPool;


    public int[][] enemyCount;




   

    

    // Start is called before the first frame update
    void Start()
    {
        
        EnemyPools = new EnemyPool[BasicAngels.Length];

        int i = 0;
        foreach (GameObject angel in BasicAngels)
        {
            GameObject pool = Instantiate(EnemyPool, transform);
            EnemyPools[i] = pool.GetComponent<EnemyPool>();
            EnemyPools[i].pooledEnemy = angel;
            EnemyPools[i].manager = GetComponent<EnemyManager>();
            EnemyPools[i].player = Player.transform;
            i++;
        }


        Invoke("SpawnEnemies", 2f);
    }

    // Update is called once per frame
    void Update()
    {
        gameTime += Time.deltaTime;
    }

    void SpawnEnemies()
    {
        foreach (EnemyPool pool in EnemyPools)
        {
            SpawnEnemy(pool, (int) pool.numberval);
        }
    }

    

    public void SpawnEnemy(EnemyPool enemypool, int enemycount)
    {

        for (int i = 0; i < enemycount + 1; i++)
        {
            bool validspawn = false;
            Vector2 testpos = new Vector2(0,0);
            while (!validspawn)
            {
                //Try a random location within 75 tiles of the player
                testpos = new Vector2(Player.transform.position.x + Random.Range(-1,2) * Random.Range(5f,75f), Player.transform.position.x + Random.Range(-1, 1) * Random.Range(5f, 75f));
                if (Physics2D.OverlapBox(testpos, new Vector2(6f, 6f), 0f) == null)
                {
                    //Spawn enemy
                    validspawn = true;
                    Debug.Log("Spawning enemy");

                }
                else
                {
                    Debug.Log("Failed test spot for enemy");

                }

                
            }
            GameObject enemyToSpawn = enemypool.GetEnemy();
            enemyToSpawn.transform.position = new Vector3(testpos.x, testpos.y, 0);
            enemyToSpawn.SetActive(true);


        }



    }



}
